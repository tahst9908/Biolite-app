// Main entry point for Biolite
void main() => runApp(MyApp());