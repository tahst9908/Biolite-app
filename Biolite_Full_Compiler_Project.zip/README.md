# Biolite Mobile App (Flutter)
This is the patient-facing app for Biolite, allowing parents/patients to create health profiles, view history, and share data via QR code.